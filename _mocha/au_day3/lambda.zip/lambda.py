import json
import pymongo
from pymongo import MongoClient

uri = "mongodb://awsmongo:nn_x_Vl(~a)_nAI?5y0V4|7K_-Q5@mealmint-recipes.c8t8o4e8myfc.us-east-1.docdb.amazonaws.com:27018/?tls=true&tlsCAFile=global-bundle.pem"
client = pymongo.MongoClient(uri)

def lambda_handler(event, context):
    print(event)
    try:
        with pymongo.MongoClient(uri) as client:
            database = client["<database name>"]
            collection = database["<collection name>"]
            # results = collection.find_one({ "recipeId" :  })

    except Exception as e:
        raise Exception(
            "The following error occurred: ", e)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
